package gianfranco.alvarez_valencia_gianfranco_psp07_tarea;

import java.security.*;
import javax.crypto.*;
import java.io.*;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Clase principal del programa para encriptar, desemcriptar y mostrar el
 * fichero original.txt de la carpeta 
 *
 * @author gianf
 */
public class Main {
    static SecretKey clave = null;//Clave que se generara al cifrar un fichero
    public static void main(String[] Args) 
    {
        //Cifrar
        cifrarFichero("original.txt");
        //Descifrar
        descifrarFichero("cifrado.txt","descifrado.txt");
        
    }

    /**
     * Método que genera la clave y cifra un fichero pasado como parámetro
     *
     * @param fichEntrada Fichero a encriptar.
     */
    private static void cifrarFichero(String fichEntrada) {
        try {
            FileInputStream fileEntrada = null; //fichero de entrada
            FileOutputStream fileSalida = null; //fichero de salida
            String usuario = "";
            String psw = "";
            
            //Entrada por teclado de nombre y psw
            Scanner sc = new Scanner(System.in);
            System.out.print("Nombre de usuario: ");
            usuario = sc.nextLine();
            System.out.print("Contraseña: ");
            psw = sc.nextLine();
            //Generar clave bytes del seed A partir de un número aleatorio con seed la cadena del nombre de usuario + password.
            SecureRandom seed = new SecureRandom();
            seed.setSeed(new String(usuario + psw).getBytes());
            KeyGenerator keyGen = KeyGenerator.getInstance("Rijndael");
            keyGen.init(128, seed);
            clave = keyGen.generateKey();
            //Inicialización del algoritmo de cifrado, modo ENCRYP
            Cipher cipher = Cipher.getInstance("Rijndael/ECB/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, clave);//Con la clave generada a partir del usuario y contraseña
            //El texto a encriptar , una vez encriptado  se almacena como un array de bytes.
            //Se usa un buffer para ir leyendo del fichero de entrada de a pocos
            byte[] buffer = new byte[1024]; //array de bytes
            //Ficheros que se usaran
            fileEntrada = new FileInputStream(fichEntrada); // fichero de entrada
            fileSalida = new FileOutputStream("cifrado.txt"); //fichero de salida
            //Salida encriptada apartir del fichero de salida y el encriptador
            CipherOutputStream cos = new CipherOutputStream(fileSalida, cipher);
            //Leer texto original
            int bytesRead = -1;
            while ((bytesRead = fileEntrada.read(buffer)) != -1)
            {
                //Escrbir texto encriptado
                cos.write(buffer, 0, bytesRead);
                cos.flush();
            }
            //Cerrar ficheros
            fileEntrada.close();
            cos.close();
            //Mostrar contenido cifrado
            System.out.println("Texto cifrado: ");
            imprimirTexto(new File("cifrado.txt"));
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchPaddingException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InvalidKeyException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
  /**
   * Método que pasado un fichero los desencripta y almacena su contenido en otro fichero cuyo nombre se pasa como parámetro.
   * @param fileEntrada Fichero a desencriptar
   * @param fileSalida  Nombre del fichero que se creará y donde se guardarán los datos desencriptados.
   */

    private static void descifrarFichero(String fileEntrada, String fileSalida)  {
        try {
            FileInputStream fichEntrada = null; //fichero de entrada
            FileOutputStream fichSalida = null; //fichero de salida
            Cipher cipher = Cipher.getInstance("Rijndael/ECB/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, clave);
            //Leer en buffer el archivo encriptado y desencriptar
            //El texto a desencriptar , una vez encriptado  se almacena como un array de bytes.
            //Se usa un buffer para ir leyendo del fichero de entrada de a pocos
            byte[] buffer = new byte[1024]; //array de bytes
            //Ficheros que se usaran
            fichEntrada = new FileInputStream(fileEntrada); // fichero de entrada
            fichSalida = new FileOutputStream(fileSalida); //fichero de salida
            //Salida encriptada apartir del fichero de salida y el encriptador
            CipherOutputStream cos = new CipherOutputStream(fichSalida, cipher);
            //Leer texto original
            int bytesRead = -1;
            while ((bytesRead = fichEntrada.read(buffer)) != -1)
            {
                //Escrbir texto encriptado
                cos.write(buffer, 0, bytesRead);
                cos.flush();
            }
            //Cerrar ficheros
            fichEntrada.close();
            cos.close();
            //Mostrar contenido descifrado
            System.out.println("Texto descifrado: ");
            imprimirTexto(new File(fileSalida));
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchPaddingException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InvalidKeyException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    /**
     * Método que pasado un fihcero lo imprime por la consola
     * @param fichImprimir Fichero a imprimir
     */
    private static void imprimirTexto(File fichImprimir)
    {
        FileReader fl = null;
        try {
            fl = new FileReader(fichImprimir);
            BufferedReader buf = new BufferedReader(fl);
            String output = "";
            while ((output = buf.readLine()) != null) {
                System.out.println("\t" + output);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                fl.close();
            } catch (IOException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}

