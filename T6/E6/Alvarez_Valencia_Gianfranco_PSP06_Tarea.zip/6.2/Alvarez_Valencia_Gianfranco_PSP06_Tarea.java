/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import java.util.regex.Pattern;
import java.util.logging.Level;
import java.util.regex.Matcher;

/**
 *
 * @author gianf
 */
public class Alvarez_Valencia_Gianfranco_PSP06_Tarea {

    public static void main(String[] args) {
        try {
            //Mascara para la entrada de datos de teclado.
            //Usuario 10 caracteres.
            Pattern usuarioMask = Pattern.compile("[A-Z]{10}");
            //Archivo 8 caracterres 3 extemsión.
            Pattern archivoMask = Pattern.compile("[a-zA-Z]{1,8}\\.[a-zA-Z]{2,3}");
            //logger para llevar el registro de la actividad del programa
            //Crear el logger
            Logger logger = Logger.getLogger("Log");
            //Asoociar al fichero log
            FileHandler fh = new FileHandler("s:\\Log.log", true);
            //Establacer el nivel de seguridad de los registros
            logger.addHandler(fh);
            logger.setLevel(Level.ALL);
            logger.setUseParentHandlers(false);
            //Estrablecer el formato
            SimpleFormatter formatter = new SimpleFormatter();
            fh.setFormatter(formatter);
            //Manejar el usuario que introduce el usuario
            //Para verificar las mascaras de entrada en bucle
            boolean usuarioOk = false;
            boolean archivoOk = false;
            boolean salir = false;
            //Para capturar los strings  de usuraio y archivo introducidos por teclado
            String usuario = "";
            String archivo = "";
            //Repetir hasta que el usurio sea correcto o decida salir
            while (usuarioOk != true) {
                //Leer por teclado
                System.out.println("Introduce el usuario que va a inciciar la aplicación, 10 letras mayusculas(0 para salir): ");
                Scanner usuTeclado = new Scanner(System.in);
                usuario = usuTeclado.nextLine();
                //Comparar si el usuario respeta la maascara definida
                if (!usuario.equals("0")) 
                {
                    Matcher compara = usuarioMask.matcher(usuario);
                    if (compara.matches()) //Si se respeta la mascara de entrada
                    {
                        System.out.println("USUARIO VALIDADO:  " + usuario);
                        logger.log(Level.INFO, "USUARIO REGISTRADO: " + usuario);//Resgistrar en el log
                        usuarioOk = true;
                        //Pedir el archivo al usuario
                        //Repetir hasta que el usurio sea correcto o decida salir
                        while (archivoOk != true) 
                        {
                            //Leer por teclado
                            System.out.println("Introduce el archivo para mostrar(El nombre del fichero es como maximo de 8 caracteres y tiene una extensión de 3 caracteres: ");
                            Scanner archTeclado = new Scanner(System.in);
                            archivo = archTeclado.nextLine();
                            //comprobar si se respta la mascara de entrada
                            if (!archivo.equals("0"))
                            {
                                Matcher comparaArch = archivoMask.matcher(archivo);
                                if (comparaArch.matches()) 
                                {
                                    System.out.println("El formato de archivo es correcto");
                                    //Mostrar el archivo
                                    //Crear un objfile con la ruta pasada
                                    File fichEvaluar = new File("./test/" + archivo);
                                    //comperobaer  si existe
                                    if (fichEvaluar.exists()) 
                                    {
                                        //Para leer el fichero
                                        BufferedReader br = new BufferedReader(new FileReader("./test/" + archivo));
                                        //Aux para leer la linea del fichero
                                        String linea = "";
                                        //Para almacenar todas las lineas del fichero
                                        String datosLinea = "";
                                        while ((linea = br.readLine()) != null) {
                                            //Formatear el string de salida
                                            datosLinea += linea + "\r\n";
                                        }
                                        //cerrar el bufferreader
                                        br.close();
                                        archivoOk = true;
                                        System.out.println("Datos del archivo: ");
                                        System.out.println(datosLinea);
                                        logger.log(Level.INFO, "Mostrado el archivo: " + archivo);
                                    }
                                    else
                                        System.out.println("El archivo no existe");
                                }
                                else 
                                    {
                                        System.out.println("El nombre del fichero es como maximo de 8 caracteres y tiene una extensión de 3 caracteres");
                                        logger.log(Level.WARNING, "NO SE ENCUENTRA EL ARCHIVO: " + archivo);
                                    }
                            }
                            else
                                System.exit(0);
                        }
                    }
                    else //No se respeta al mascara de entrada
                    {
                        System.out.println("EL USUARIO TIENE QUE SER DE 10 CARACTERES MAYUSCULAS");
                        logger.log(Level.WARNING, "INTENTO FALLIFDO USUARIO NO REGISTRADO: " + usuario);
                    }
                }
                else
                    System.exit(0);
                }

            }catch (IOException ex) {
            Logger.getLogger(Alvarez_Valencia_Gianfranco_PSP06_Tarea.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
            }catch (SecurityException ex) {
            Logger.getLogger(Alvarez_Valencia_Gianfranco_PSP06_Tarea.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        }
    }
